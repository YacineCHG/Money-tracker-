import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'dart:convert';

void main() {
  runApp(const MoneyTrackerEnhanced());
}

class MoneyTrackerEnhanced extends StatelessWidget {
  const MoneyTrackerEnhanced({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Money Tracker Pro',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Inter',
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        fontFamily: 'Inter',
      ),
      home: const HomePageEnhanced(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePageEnhanced extends StatefulWidget {
  const HomePageEnhanced({super.key});

  @override
  State<HomePageEnhanced> createState() => _HomePageEnhancedState();
}

class _HomePageEnhancedState extends State<HomePageEnhanced> with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> _transactions = [];
  double _balance = 0;
  double _totalIncome = 0;
  double _totalExpense = 0;
  bool _isLoading = true;
  String _filterType = 'all';
  late TabController _tabController;
  double _monthlyBudget = 10000.0;
  bool _isDarkMode = false;
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();

  
  final List<String> _incomeCategories = [
    'Salaire', 'Bourse', 'Investissement', 'Cadeau', 'Remboursement', 
    'Prime', 'Rente', 'Freelance', 'Vente', 'Autre revenu'
  ];

  final List<String> _expenseCategories = [
    'Nourriture', 'Transport', 'Loisir', 'Santé', 'Achat', 
    'Logement', 'Éducation', 'Factures', 'Restaurant', 'Autre dépense'
  ];

  final Map<String, IconData> _categoryIcons = {
  
    'Salaire': Icons.account_balance_wallet,
    'Bourse': Icons.school,
    'Investissement': Icons.trending_up,
    'Cadeau': Icons.card_giftcard,
    'Remboursement': Icons.payment,
    'Prime': Icons.workspace_premium,
    'Rente': Icons.account_balance,
    'Freelance': Icons.computer,
    'Vente': Icons.shopping_bag,
    'Autre revenu': Icons.attach_money,
    
    
    'Nourriture': Icons.restaurant,
    'Transport': Icons.directions_car,
    'Loisir': Icons.sports_esports,
    'Santé': Icons.local_hospital,
    'Achat': Icons.shopping_cart,
    'Logement': Icons.home,
    'Éducation': Icons.school,
    'Factures': Icons.receipt,
    'Restaurant': Icons.restaurant_menu,
    'Autre dépense': Icons.category,
  };

  final Map<String, Color> _categoryColors = {
    
    'Salaire': Colors.green.shade400,
    'Bourse': Colors.lightGreen.shade400,
    'Investissement': Colors.teal.shade400,
    'Cadeau': Colors.lime.shade400,
    'Remboursement': Colors.greenAccent.shade400,
    'Prime': Colors.deepPurple.shade400,
    'Rente': Colors.cyan.shade400,
    'Freelance': Colors.tealAccent.shade400,
    'Vente': Colors.lightGreenAccent.shade400,
    'Autre revenu': Colors.green.shade300,
    
    
    'Nourriture': Colors.orange.shade400,
    'Transport': Colors.blue.shade400,
    'Loisir': Colors.purple.shade400,
    'Santé': Colors.pink.shade400,
    'Achat': Colors.red.shade400,
    'Logement': Colors.deepOrange.shade400,
    'Éducation': Colors.indigo.shade400,
    'Factures': Colors.blueGrey.shade400,
    'Restaurant': Colors.amber.shade400,
    'Autre dépense': Colors.grey.shade400,
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList('transactions') ?? [];
    
    _transactions = data.map((e) => json.decode(e) as Map<String, dynamic>).toList();
    
    _monthlyBudget = prefs.getDouble('monthly_budget') ?? 10000.0;
    _isDarkMode = prefs.getBool('is_dark_mode') ?? false;
    
    _calculateTotals();
    
    setState(() => _isLoading = false);
  }

  void _calculateTotals() {
    _totalIncome = _transactions
        .where((t) => t['isIncome'])
        .fold(0.0, (sum, t) => sum + (t['amount'] as double));
    
    _totalExpense = _transactions
        .where((t) => !t['isIncome'])
        .fold(0.0, (sum, t) => sum + (t['amount'] as double));
    
    _balance = _totalIncome - _totalExpense;
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    final data = _transactions.map((t) => json.encode(t)).toList();
    await prefs.setStringList('transactions', data);
    await prefs.setDouble('monthly_budget', _monthlyBudget);
    await prefs.setBool('is_dark_mode', _isDarkMode);
  }

  void _resetWallet() {
  showDialog(
    context: context,
    builder: (ctx) {
      return AlertDialog(
        title: const Text('Réinitialiser le portefeuille'),
        content: const Text(
          'Êtes-vous sûr de vouloir tout supprimer ?\n'
          'Cette action supprimera toutes les transactions, '
          'réinitialisera le budget et remettra tout à zéro.\n\n'
          'Cette action est irréversible.',
        ),
        icon: const Icon(Icons.warning, color: Colors.orange, size: 48),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx); 
              
              // Confirmation supplémentaire ta3 efface
              final confirm = await showDialog(
                context: context,
                builder: (ctx2) {
                  return AlertDialog(
                    title: const Text('Confirmation finale'),
                    content: const Text(
                      'Tapez "SUPPRIMER" pour confirmer la réinitialisation complète.',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx2, false),
                        child: const Text('Annuler'),
                      ),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(ctx2, true),
                        child: const Text('Continuer'),
                      ),
                    ],
                  );
                },
              );
              
              if (confirm == true) {
                setState(() {
                  _transactions.clear();
                  _balance = 0;
                  _totalIncome = 0;
                  _totalExpense = 0;
                  _monthlyBudget = 10000.0;
                  _filterType = 'all';
                  _searchController.clear();
                  _isSearching = false;
                });
                
                // Sauvegarder les données réinitialisées
                _saveData();
                
                // Afficher un message de confirmation
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Portefeuille réinitialisé avec succès'),
                    backgroundColor: Colors.green,
                    duration: Duration(seconds: 2),
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Réinitialiser', style: TextStyle(color: Colors.white)),
          ),
        ],
      );
    },
  );
}

void _showResetOptions() {
  showModalBottomSheet(
    context: context,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
    ),
    builder: (ctx) {
      return Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.restart_alt, size: 30, color: Colors.deepPurple),
            const SizedBox(height: 5),
            const Text(
              'Options de réinitialisation',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            ListTile(
              leading: const Icon(Icons.delete_sweep, color: Colors.red),
              title: const Text('Tout supprimer'),
              subtitle: const Text('Supprime toutes les transactions'),
              onTap: () {
                Navigator.pop(ctx);
                _resetWallet();
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings_backup_restore, color: Colors.blue),
              title: const Text('Réinitialiser le budget'),
              subtitle: const Text('Remet le budget à 10 000 DA'),
              onTap: () {
                setState(() {
                  _monthlyBudget = 10000.0;
                  _saveData();
                });
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Budget réinitialisé à 10 000 DA'),
                    backgroundColor: Colors.blue,
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.filter_alt_off, color: Colors.orange),
              title: const Text('Réinitialiser les filtres'),
              subtitle: const Text('Remet tous les filtres à zéro'),
              onTap: () {
                setState(() {
                  _filterType = 'all';
                  _searchController.clear();
                  _isSearching = false;
                });
                Navigator.pop(ctx);
              },
            ),
            const SizedBox(height: 5),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Annuler'),
            ),
          ],
        ),
      );
    },
  );
}

  void _addTransaction(String title, double amount, String category, bool isIncome) {
    final transaction = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'title': title,
      'amount': amount,
      'category': category,
      'isIncome': isIncome,
      'date': DateTime.now().toIso8601String(),
    };
    
    setState(() {
      _transactions.insert(0, transaction);
      _calculateTotals();
    });
    
    _saveData();
  }

  void _editTransaction(String id, String title, double amount, String category, bool isIncome) {
    final index = _transactions.indexWhere((t) => t['id'] == id);
    if (index != -1) {
      setState(() {
        _transactions[index] = {
          'id': id,
          'title': title,
          'amount': amount,
          'category': category,
          'isIncome': isIncome,
          'date': DateTime.now().toIso8601String(),
        };
        _calculateTotals();
      });
      _saveData();
    }
  }

  void _deleteTransaction(String id) {
    setState(() {
      _transactions.removeWhere((t) => t['id'] == id);
      _calculateTotals();
    });
    
    _saveData();
  }

  void _showAddDialog(bool isIncome, {Map<String, dynamic>? transactionToEdit}) {
    final titleController = TextEditingController(text: transactionToEdit?['title']);
    final amountController = TextEditingController(
        text: transactionToEdit?['amount']?.toString() ?? '');
    
    // Utiliser la liste appropriée selon le type
    final List<String> categories = isIncome ? _incomeCategories : _expenseCategories;
    String selectedCategory = transactionToEdit?['category'] ?? categories[0];
    bool isEditing = transactionToEdit != null;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: Container(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          isEditing 
                            ? 'Modifier la transaction'
                            : isIncome 
                                ? 'Nouveau revenu' 
                                : 'Nouvelle dépense',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(ctx),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: titleController,
                      decoration: InputDecoration(
                        labelText: 'Description',
                        prefixIcon: const Icon(Icons.description),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: amountController,
                      decoration: InputDecoration(
                        labelText: 'Montant (DA)',
                        prefixIcon: const Icon(Icons.attach_money),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: selectedCategory,
                      items: categories.map((c) => 
                        DropdownMenuItem(
                          value: c,
                          child: Row(
                            children: [
                              Icon(_categoryIcons[c], color: _categoryColors[c]),
                              const SizedBox(width: 12),
                              Text(c),
                            ],
                          ),
                        )
                      ).toList(),
                      onChanged: (value) => setState(() => selectedCategory = value!),
                      decoration: InputDecoration(
                        labelText: 'Catégorie',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    if (!isEditing)
                      SegmentedButton<bool>(
                        segments: const [
                          ButtonSegment(
                            value: false,
                            label: Text('Dépense'),
                            icon: Icon(Icons.arrow_upward),
                          ),
                          ButtonSegment(
                            value: true,
                            label: Text('Revenu'),
                            icon: Icon(Icons.arrow_downward),
                          ),
                        ],
                        selected: {isIncome},
                        onSelectionChanged: (Set<bool> newSelection) {
                          Navigator.pop(ctx);
                          _showAddDialog(newSelection.first);
                        },
                      ),
                    const SizedBox(height: 32),
                    Row(
                      children: [
                        if (isEditing)
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () {
                                _deleteTransaction(transactionToEdit['id']);
                                Navigator.pop(ctx);
                              },
                              style: OutlinedButton.styleFrom(
                                foregroundColor: Colors.red,
                                padding: const EdgeInsets.symmetric(vertical: 16),
                              ),
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.delete, size: 20),
                                  SizedBox(width: 8),
                                  Text('Supprimer'),
                                ],
                              ),
                            ),
                          ),
                        if (isEditing) const SizedBox(width: 12),
                        Expanded(
                          child: FilledButton(
                            onPressed: () {
                              final title = titleController.text.trim();
                              final amount = double.tryParse(amountController.text.trim());
                              
                              if (title.isNotEmpty && amount != null && amount > 0) {
                                if (isEditing) {
                                  _editTransaction(
                                    transactionToEdit['id'],
                                    title,
                                    amount,
                                    selectedCategory,
                                    isIncome,
                                  );
                                } else {
                                  _addTransaction(title, amount, selectedCategory, isIncome);
                                }
                                Navigator.pop(ctx);
                              }
                            },
                            style: FilledButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(isEditing ? Icons.save : Icons.add),
                                const SizedBox(width: 8),
                                Text(isEditing ? 'Sauvegarder' : 'Ajouter'),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showBudgetDialog() {
    final controller = TextEditingController(text: _monthlyBudget.toStringAsFixed(0));
    
    showDialog(
      context: context,
      builder: (ctx) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.savings, size: 48, color: Colors.deepPurple),
                const SizedBox(height: 16),
                const Text(
                  'Budget mensuel',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: controller,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.attach_money),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Annuler'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () {
                          final amount = double.tryParse(controller.text.trim());
                          if (amount != null && amount > 0) {
                            setState(() {
                              _monthlyBudget = amount;
                              _saveData();
                            });
                            Navigator.pop(ctx);
                          }
                        },
                        child: const Text('Définir'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  List<Map<String, dynamic>> get _filteredTransactions {
    List<Map<String, dynamic>> filtered = _transactions;
    
    if (_filterType == 'income') {
      filtered = filtered.where((t) => t['isIncome']).toList();
    } else if (_filterType == 'expense') {
      filtered = filtered.where((t) => !t['isIncome']).toList();
    }
    
    if (_searchController.text.isNotEmpty) {
      final searchTerm = _searchController.text.toLowerCase();
      filtered = filtered.where((t) {
        return t['title'].toString().toLowerCase().contains(searchTerm) ||
               t['category'].toString().toLowerCase().contains(searchTerm);
      }).toList();
    }
    
    return filtered;
  }

  Map<String, double> get _categoryExpenses {
    final Map<String, double> expenses = {};
    
    for (final t in _transactions.where((t) => !t['isIncome'])) {
      final category = t['category'];
      final amount = t['amount'] as double;
      expenses[category] = (expenses[category] ?? 0) + amount;
    }
    
    return expenses;
  }

  Map<String, double> get _categoryIncomes {
    final Map<String, double> incomes = {};
    
    for (final t in _transactions.where((t) => t['isIncome'])) {
      final category = t['category'];
      final amount = t['amount'] as double;
      incomes[category] = (incomes[category] ?? 0) + amount;
    }
    
    return incomes;
  }

  double get _monthlyExpense {
    final now = DateTime.now();
    return _transactions
        .where((t) => !t['isIncome'] && 
            DateTime.parse(t['date']).month == now.month &&
            DateTime.parse(t['date']).year == now.year)
        .fold(0.0, (sum, t) => sum + (t['amount'] as double));
  }

  Widget _buildBalanceCard() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Theme.of(context).colorScheme.primary,
            Theme.of(context).colorScheme.primaryContainer,
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Solde actuel',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onPrimary,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${_balance.toStringAsFixed(2)} DA',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onPrimary,
              fontSize: 40,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem(
                'Revenus',
                _totalIncome,
                Icons.arrow_downward,
                Colors.green.shade400,
              ),
              Container(
                width: 1,
                height: 40,
                color: Colors.white.withOpacity(0.3),
              ),
              _buildStatItem(
                'Dépenses',
                _totalExpense,
                Icons.arrow_upward,
                Colors.red.shade400,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, double value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary.withOpacity(0.8),
            fontSize: 12,
          ),
        ),
        Text(
          '${value.toStringAsFixed(2)} DA',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ],
    );
  }

  Widget _buildStatsTab() {
    final monthlyExpense = _monthlyExpense;
    final budgetPercentage = (_monthlyBudget > 0) 
        ? (monthlyExpense / _monthlyBudget) * 100 
        : 0;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Budget mensuel',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: _showBudgetDialog,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Stack(
                    children: [
                      Container(
                        height: 12,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 500),
                        height: 12,
                        width: (budgetPercentage > 100 
                            ? 1.0 
                            : budgetPercentage / 100) * MediaQuery.of(context).size.width * 0.9,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: budgetPercentage > 100 
                                ? [Colors.red.shade400, Colors.red.shade600]
                                : budgetPercentage > 80 
                                    ? [Colors.orange.shade400, Colors.orange.shade600]
                                    : [Colors.green.shade400, Colors.green.shade600],
                          ),
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${monthlyExpense.toStringAsFixed(0)} DA',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Dépensé',
                            style: TextStyle(
                              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '${_monthlyBudget.toStringAsFixed(0)} DA',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Budget',
                            style: TextStyle(
                              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    budgetPercentage > 100 
                        ? '⚠️ Budget dépassé de ${(monthlyExpense - _monthlyBudget).toStringAsFixed(0)} DA'
                        : '✅ Il reste ${(_monthlyBudget - monthlyExpense).toStringAsFixed(0)} DA',
                    style: TextStyle(
                      color: budgetPercentage > 100 ? Colors.red : Colors.green,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Dépenses par catégorie',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ..._categoryExpenses.entries.map((entry) {
                    final percentage = _totalExpense > 0 
                        ? (entry.value / _totalExpense * 100) 
                        : 0;
                    
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: _categoryColors[entry.key]?.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              _categoryIcons[entry.key],
                              color: _categoryColors[entry.key],
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  entry.key,
                                  style: const TextStyle(fontWeight: FontWeight.w500),
                                ),
                                const SizedBox(height: 4),
                                LinearProgressIndicator(
                                  value: percentage / 100,
                                  backgroundColor: Colors.grey.shade200,
                                  color: _categoryColors[entry.key],
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '${entry.value.toStringAsFixed(0)} DA',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              Text(
                                '${percentage.toStringAsFixed(1)}%',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Revenus par catégorie',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ..._categoryIncomes.entries.map((entry) {
                    final percentage = _totalIncome > 0 
                        ? (entry.value / _totalIncome * 100) 
                        : 0;
                    
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: _categoryColors[entry.key]?.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              _categoryIcons[entry.key],
                              color: _categoryColors[entry.key],
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  entry.key,
                                  style: const TextStyle(fontWeight: FontWeight.w500),
                                ),
                                const SizedBox(height: 4),
                                LinearProgressIndicator(
                                  value: percentage / 100,
                                  backgroundColor: Colors.grey.shade200,
                                  color: _categoryColors[entry.key],
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '${entry.value.toStringAsFixed(0)} DA',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              Text(
                                '${percentage.toStringAsFixed(1)}%',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(Icons.insights, size: 48, color: Colors.deepPurple),
                  const SizedBox(height: 16),
                  Text(
                    'Résumé financier',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildSummaryItem('Total des transactions', '${_transactions.length}'),
                  _buildSummaryItem('Nombre de revenus', '${_transactions.where((t) => t['isIncome']).length}'),
                  _buildSummaryItem('Nombre de dépenses', '${_transactions.where((t) => !t['isIncome']).length}'),
                  _buildSummaryItem('Plus grosse dépense', '${_getLargestExpense().toStringAsFixed(2)} DA'),
                  _buildSummaryItem('Plus gros revenu', '${_getLargestIncome().toStringAsFixed(2)} DA'),
                  _buildSummaryItem('Dépense moyenne', '${_getAverageExpense().toStringAsFixed(2)} DA'),
                  _buildSummaryItem('Revenu moyen', '${_getAverageIncome().toStringAsFixed(2)} DA'),
                  _buildSummaryItem('Catégorie dépensière', _getTopExpenseCategory()),
                  _buildSummaryItem('Catégorie lucrative', _getTopIncomeCategory()),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.lightbulb, color: Colors.amber),
                      const SizedBox(width: 8),
                      Text(
                        'Conseils financiers',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ..._getMoneyTips().map((tip) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          margin: const EdgeInsets.only(top: 6, right: 12),
                          decoration: const BoxDecoration(
                            color: Colors.amber,
                            shape: BoxShape.circle,
                          ),
                        ),
                        Expanded(
                          child: Text(
                            tip,
                            style: const TextStyle(fontSize: 15),
                          ),
                        ),
                      ],
                    ),
                  )).toList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  double _getLargestExpense() {
    if (_transactions.isEmpty) return 0;
    return _transactions
        .where((t) => !t['isIncome'])
        .fold(0.0, (max, t) => (t['amount'] as double) > max ? t['amount'] as double : max);
  }

  double _getLargestIncome() {
    if (_transactions.isEmpty) return 0;
    return _transactions
        .where((t) => t['isIncome'])
        .fold(0.0, (max, t) => (t['amount'] as double) > max ? t['amount'] as double : max);
  }

  double _getAverageExpense() {
    final expenses = _transactions.where((t) => !t['isIncome']);
    if (expenses.isEmpty) return 0;
    return expenses.fold(0.0, (sum, t) => sum + (t['amount'] as double)) / expenses.length;
  }

  double _getAverageIncome() {
    final incomes = _transactions.where((t) => t['isIncome']);
    if (incomes.isEmpty) return 0;
    return incomes.fold(0.0, (sum, t) => sum + (t['amount'] as double)) / incomes.length;
  }

  String _getTopExpenseCategory() {
    if (_categoryExpenses.isEmpty) return 'Aucune';
    final sorted = _categoryExpenses.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.first.key;
  }

  String _getTopIncomeCategory() {
    if (_categoryIncomes.isEmpty) return 'Aucune';
    final sorted = _categoryIncomes.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.first.key;
  }

  List<String> _getMoneyTips() {
    final tips = <String>[];
    
    if (_balance < 0) {
      tips.add('Votre solde est négatif. Essayez de réduire vos dépenses non essentielles.');
    }
    
    if (_totalExpense > _totalIncome * 0.8) {
      tips.add('Vos dépenses représentent plus de 80% de vos revenus. Pensez à épargner davantage.');
    }
    
    if (_monthlyExpense > _monthlyBudget) {
      tips.add('Vous dépassez votre budget mensuel. Revoyez vos dépenses.');
    }
    
    // Conseils basés sur les catégories de dépenses
    final topExpense = _getTopExpenseCategory();
    if (topExpense != 'Aucune') {
      if (topExpense == 'Restaurant') {
        tips.add('Vous dépensez beaucoup au restaurant. Pensez à cuisiner plus souvent.');
      } else if (topExpense == 'Loisir') {
        tips.add('Vos dépenses de loisir sont élevées. Cherchez des activités gratuites.');
      } else if (topExpense == 'Transport') {
        tips.add('Les transports coûtent cher. Pensez au covoiturage ou aux transports en commun.');
      }
    }
    
    if (tips.isEmpty) {
      tips.add('Vous gérez bien vos finances ! Continuez ainsi.');
      tips.add('Pensez à épargner au moins 10% de vos revenus chaque mois.');
      tips.add('Revoyez vos abonnements inutilisés pour économiser.');
      tips.add('Diversifiez vos sources de revenus pour plus de sécurité financière.');
    }
    
    return tips;
  }

  Widget _buildTransactionItem(Map<String, dynamic> transaction) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: _categoryColors[transaction['category']]?.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            _categoryIcons[transaction['category']],
            color: _categoryColors[transaction['category']],
          ),
        ),
        title: Text(
          transaction['title'],
          style: const TextStyle(fontWeight: FontWeight.w500),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 2),
            Text(
              transaction['category'],
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            Text(
              DateFormat('dd MMM yyyy - HH:mm').format(DateTime.parse(transaction['date'])),
              style: TextStyle(
                fontSize: 11,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
              ),
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '${transaction['isIncome'] ? '+' : '-'}${transaction['amount'].toStringAsFixed(2)} DA',
              style: TextStyle(
                color: transaction['isIncome'] ? Colors.green.shade600 : Colors.red.shade600,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 2),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: transaction['isIncome'] 
                    ? Colors.green.shade100 
                    : Colors.red.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                transaction['isIncome'] ? 'Revenu' : 'Dépense',
                style: TextStyle(
                  fontSize: 10,
                  color: transaction['isIncome'] 
                      ? Colors.green.shade800 
                      : Colors.red.shade800,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
        onTap: () => _showAddDialog(transaction['isIncome'], transactionToEdit: transaction),
      ),
    );
  }

  @override
  // Modifiez uniquement la méthode build du Scaffold (vers la fin du code)
@override
Widget build(BuildContext context) {
  if (_isLoading) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 20),
            Text(
              'Chargement...',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }

  final filteredTransactions = _filteredTransactions;

  return Scaffold(
    appBar: AppBar(
      title: _isSearching
          ? TextField(
              controller: _searchController,
              autofocus: true,
              decoration: InputDecoration(
                hintText: 'Rechercher...',
                border: InputBorder.none,
                suffixIcon: IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () {
                    setState(() {
                      _isSearching = false;
                      _searchController.clear();
                    });
                  },
                ),
              ),
              onChanged: (_) => setState(() {}),
            )
          : const Text('Money Tracker Pro'),
      actions: [
        if (!_isSearching)
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => setState(() => _isSearching = true),
          ),
        IconButton(
          icon: const Icon(Icons.restart_alt),
          onPressed: _showResetOptions,
          tooltip: 'Réinitialiser le portefeuille',
        ),
        IconButton(
          icon: Icon(_isDarkMode ? Icons.light_mode : Icons.dark_mode),
          onPressed: () {
            setState(() {
              _isDarkMode = !_isDarkMode;
              _saveData();
            });
          },
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(0),
        child: Container(),
      ),
    ),
    body: SingleChildScrollView(
      child: Column(
        children: [
          _buildBalanceCard(),
          
          // Boutons Revenu/Dépense
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _showAddDialog(true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade400,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: const Icon(Icons.add),
                    label: const Text(
                      'Nouveau Revenu',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _showAddDialog(false),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.shade400,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: const Icon(Icons.remove),
                    label: const Text(
                      'Nouvelle Dépense',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // Filtres
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SegmentedButton<String>(
              segments: const [
                ButtonSegment(
                  value: 'all',
                  label: Text('Toutes'),
                  icon: Icon(Icons.list),
                ),
                ButtonSegment(
                  value: 'income',
                  label: Text('Revenus'),
                  icon: Icon(Icons.arrow_downward),
                ),
                ButtonSegment(
                  value: 'expense',
                  label: Text('Dépenses'),
                  icon: Icon(Icons.arrow_upward),
                ),
              ],
              selected: {_filterType},
              onSelectionChanged: (Set<String> newSelection) {
                setState(() => _filterType = newSelection.first);
              },
            ),
          ),
          
          // Section Statistiques rapides
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Statistiques du mois',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.insights),
                          onPressed: () {
                            // Navigation vers les statistiques détaillées
                            DefaultTabController.of(context).animateTo(1);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildMiniStatItem(
                          'Budget',
                          '${_monthlyBudget.toStringAsFixed(0)} DA',
                          Icons.account_balance_wallet,
                          Colors.blue,
                        ),
                        _buildMiniStatItem(
                          'Dépensé',
                          '${_monthlyExpense.toStringAsFixed(0)} DA',
                          Icons.trending_up,
                          Colors.red,
                        ),
                        _buildMiniStatItem(
                          'Restant',
                          '${(_monthlyBudget - _monthlyExpense).toStringAsFixed(0)} DA',
                          Icons.savings,
                          Colors.green,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          // Titre des transactions
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Transactions récentes',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Total: ${filteredTransactions.length}',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
          
          // Liste des transactions
          filteredTransactions.isEmpty
              ? Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    children: [
                      Icon(
                        Icons.receipt_long,
                        size: 80,
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        _searchController.text.isEmpty
                            ? 'Aucune transaction'
                            : 'Aucun résultat',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                          fontSize: 18,
                        ),
                      ),
                      if (_searchController.text.isNotEmpty)
                        TextButton(
                          onPressed: () {
                            setState(() {
                              _searchController.clear();
                              _isSearching = false;
                            });
                          },
                          child: const Text('Effacer la recherche'),
                        ),
                    ],
                  ),
                )
              : ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  padding: const EdgeInsets.only(bottom: 100),
                  itemCount: filteredTransactions.length,
                  itemBuilder: (context, index) {
                    final t = filteredTransactions[index];
                    return Dismissible(
                      key: Key(t['id']),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        decoration: BoxDecoration(
                          color: Colors.red.shade400,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        child: const Icon(Icons.delete, color: Colors.white),
                      ),
                      onDismissed: (_) => _deleteTransaction(t['id']),
                      child: _buildTransactionItem(t),
                    );
                  },
                ),
          
          const SizedBox(height: 80), // Espace pour éviter que le contenu soit caché
        ],
      ),
    ),
    
   
    bottomNavigationBar: BottomNavigationBar(
      currentIndex: 0,
      onTap: (index) {
        if (index == 1) {
          // Aller aux statistiques
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Scaffold(
                appBar: AppBar(
                  title: const Text('Statistiques'),
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                body: _buildStatsTab(),
              ),
            ),
          );
        } else if (index == 2) {
          // Aller au résumé
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Scaffold(
                appBar: AppBar(
                  title: const Text('Résumé financier'),
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                body: _buildSummaryTab(),
              ),
            ),
          );
        }
      },
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Accueil',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.pie_chart),
          label: 'Statistiques',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.summarize),
          label: 'Résumé',
        ),
      ],
    ),
    
    
  );
}


Widget _buildMiniStatItem(String label, String value, IconData icon, Color color) {
  return Column(
    children: [
      Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color, size: 20),
      ),
      const SizedBox(height: 4),
      Text(
        label,
        style: const TextStyle(fontSize: 12),
      ),
      Text(
        value,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
      ),
    ],
  );
}
}