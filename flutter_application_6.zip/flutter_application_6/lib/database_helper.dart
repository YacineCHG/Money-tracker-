import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }
  // Ajoutez cette méthode dans votre DatabaseHelper
Future<String> exportDatabaseToFile() async {
  try {
    // Chemin de la base de données
    final dbPath = join(await getDatabasesPath(), 'money_tracker.db');
    final dbFile = File(dbPath);
    
    // Chemin de destination pour l'export
    final directory = await getExternalStorageDirectory();
    final exportPath = '${directory?.path}/money_tracker_export.db';
    final exportFile = File(exportPath);
    
    // Copier le fichier
    await dbFile.copy(exportPath);
    
    // Obtenir les informations sur les tables
    final db = await database;
    final tables = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    );
    
    String content = '=== INFORMATIONS SUR LA BASE DE DONNÉES ===\n\n';
    content += 'Chemin: $dbPath\n';
    content += 'Taille: ${dbFile.lengthSync()} bytes\n';
    content += 'Exporté vers: $exportPath\n\n';
    
    for (final table in tables) {
      final tableName = table['name'] as String;
      final countResult = await db.rawQuery(
        'SELECT COUNT(*) as count FROM $tableName'
      );
      final count = countResult.first['count'] as int;
      
      content += '=== TABLE: $tableName (${count} enregistrements) ===\n';
      
      // Récupérer les données de la table (limité à 100 lignes)
      final data = await db.query(
        tableName,
        limit: 100,
        orderBy: tableName == 'transactions' ? 'date DESC' : 'key'
      );
      
      if (data.isNotEmpty) {
        // En-têtes
        final headers = data.first.keys;
        content += headers.join(' | ') + '\n';
        content += List.filled(headers.length, '---').join(' | ') + '\n';
        
        // Données
        for (final row in data) {
          final values = headers.map((h) => row[h].toString()).toList();
          content += values.join(' | ') + '\n';
        }
      }
      content += '\n';
    }
    
    // Écrire dans un fichier texte
    final textFile = File('${directory?.path}/database_info.txt');
    await textFile.writeAsString(content);
    
    return exportPath;
  } catch (e) {
    print('Erreur lors de l\'export: $e');
    rethrow;
  }
}

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'money_tracker.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // Table pour les transactions
    await db.execute('''
      CREATE TABLE transactions(
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        category TEXT NOT NULL,
        isIncome INTEGER NOT NULL,
        date TEXT NOT NULL,
        createdAt TEXT NOT NULL
      )
    ''');

    // Table pour les paramètres
    await db.execute('''
      CREATE TABLE settings(
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');

    // Insérer les valeurs par défaut
    await db.insert('settings', {
      'key': 'monthly_budget',
      'value': '10000.0'
    });
    await db.insert('settings', {
      'key': 'is_dark_mode',
      'value': 'false'
    });
  }

  // CRUD pour les transactions
  Future<void> insertTransaction(Map<String, dynamic> transaction) async {
    final db = await database;
    await db.insert('transactions', {
      'id': transaction['id'],
      'title': transaction['title'],
      'amount': transaction['amount'],
      'category': transaction['category'],
      'isIncome': transaction['isIncome'] ? 1 : 0,
      'date': transaction['date'],
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> getAllTransactions() async {
    final db = await database;
    return await db.query('transactions', orderBy: 'date DESC');
  }

  Future<void> updateTransaction(Map<String, dynamic> transaction) async {
    final db = await database;
    await db.update(
      'transactions',
      {
        'title': transaction['title'],
        'amount': transaction['amount'],
        'category': transaction['category'],
        'isIncome': transaction['isIncome'] ? 1 : 0,
        'date': transaction['date'],
      },
      where: 'id = ?',
      whereArgs: [transaction['id']],
    );
  }

  Future<void> deleteTransaction(String id) async {
    final db = await database;
    await db.delete(
      'transactions',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteAllTransactions() async {
    final db = await database;
    await db.delete('transactions');
  }

  // Méthodes pour les paramètres
  Future<void> setSetting(String key, String value) async {
    final db = await database;
    await db.insert(
      'settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<String?> getSetting(String key) async {
    final db = await database;
    final result = await db.query(
      'settings',
      where: 'key = ?',
      whereArgs: [key],
    );
    if (result.isNotEmpty) {
      return result.first['value'] as String?;
    }
    return null;
  }

  // Statistiques
  Future<double> getTotalIncome() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT SUM(amount) as total FROM transactions WHERE isIncome = 1'
    );
    return result.first['total'] as double? ?? 0.0;
  }

  Future<double> getTotalExpense() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT SUM(amount) as total FROM transactions WHERE isIncome = 0'
    );
    return result.first['total'] as double? ?? 0.0;
  }

  Future<double> getMonthlyExpense() async {
    final db = await database;
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1).toIso8601String();
    final result = await db.rawQuery('''
      SELECT SUM(amount) as total FROM transactions 
      WHERE isIncome = 0 AND date >= ?
    ''', [startOfMonth]);
    return result.first['total'] as double? ?? 0.0;
  }

  // Fermer la base de données
  Future<void> close() async {
    final db = await database;
    await db.close();
  }
}